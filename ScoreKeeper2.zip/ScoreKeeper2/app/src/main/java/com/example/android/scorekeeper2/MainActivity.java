package com.example.android.scorekeeper2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int scoreBlackStars = 0;
    int scoreSuperEagles = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int score = 0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    /**

     * Displays the given score for Black Stars.

     */

    public void displayForBlackStars(int score) {

        TextView scoreView = (TextView) findViewById(R.id.black_stars_score);

        scoreView.setText(String.valueOf(score));

    }

    /***
     * This method is called and a point is added when the +1 button is clicked
     */

    public void onepoint (View view) {
        scoreBlackStars = scoreBlackStars + 1;
        displayForBlackStars (scoreBlackStars);

    }

    /***
     * This method is called and a point is added when the +1 button is clicked
     */


    public void foul (View view){
        scoreBlackStars = scoreBlackStars + 1;
        displayForBlackStars ( scoreBlackStars );
    }

    /**

     * Displays the given score for Super Eagles.

     */


    public void displayForSuperEagles(int score){

        TextView scoreView = (TextView)findViewById(R.id.super_eagles_score);
        scoreView.setText(String.valueOf(score));

    }

    /***
     * This method is called and a point is added when the +1 button is clicked
     */


    public void onepointB (View View) {
        scoreSuperEagles = scoreSuperEagles + 1;
        displayForSuperEagles (scoreSuperEagles);
    }

    /***
     * This method is called and a point is added when the +1 button is clicked
     */

    public void foulB (View view){
        scoreSuperEagles = scoreSuperEagles + 1;
        displayForSuperEagles ( scoreSuperEagles );
    }



}



